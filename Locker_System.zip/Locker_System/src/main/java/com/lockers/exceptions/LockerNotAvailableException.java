package com.lockers.exceptions;

public class LockerNotAvailableException extends Exception {

    public LockerNotAvailableException(String message) {
        super(message);
    }

    public LockerNotAvailableException(String message, Throwable cause) {
        super(message, cause);
    }
}