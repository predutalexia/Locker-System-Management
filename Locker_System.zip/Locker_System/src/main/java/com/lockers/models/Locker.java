package com.lockers.models;

import com.lockers.interfaces.Identifiable;
import com.lockers.interfaces.Validatable;
import com.lockers.exceptions.InvalidInputException;

public class Locker implements Identifiable, Validatable {

    private String id;
    private String locationId;
    private String lockerNumber;
    private LockerSize size;
    private LockerStatus status;
    private double hourlyRate;

    public Locker(String locationId, String lockerNumber, LockerSize size, double hourlyRate) {
        this.locationId = locationId;
        this.lockerNumber = lockerNumber;
        this.size = size;
        this.hourlyRate = hourlyRate;
        this.status = LockerStatus.AVAILABLE;
        this.id = locationId + "-" + lockerNumber;
    }

    public Locker() {
        this.status = LockerStatus.AVAILABLE;
    }

    @Override
    public void validate() throws InvalidInputException {
        if (lockerNumber == null || lockerNumber.trim().isEmpty()) {
            throw new InvalidInputException("Locker number cannot be empty");
        }
        if (size == null) {
            throw new InvalidInputException("Locker size must be set");
        }
        if (hourlyRate <= 0) {
            throw new InvalidInputException("Hourly rate must be positive");
        }
    }

    public boolean isAvailable() {
        return status == LockerStatus.AVAILABLE;
    }

    public void occupy() {
        this.status = LockerStatus.OCCUPIED;
    }

    public void release() {
        this.status = LockerStatus.AVAILABLE;
    }

    public double calculateCost(int hours) {
        return hourlyRate * hours;
    }

    // Getters and Setters
    @Override
    public String getId() { return id; }

    @Override
    public void setId(String id) { this.id = id; }

    public String getLocationId() { return locationId; }
    public void setLocationId(String locationId) { this.locationId = locationId; }

    public String getLockerNumber() { return lockerNumber; }
    public void setLockerNumber(String lockerNumber) { this.lockerNumber = lockerNumber; }

    public LockerSize getSize() { return size; }
    public void setSize(LockerSize size) { this.size = size; }

    public LockerStatus getStatus() { return status; }
    public void setStatus(LockerStatus status) { this.status = status; }

    public double getHourlyRate() { return hourlyRate; }
    public void setHourlyRate(double hourlyRate) { this.hourlyRate = hourlyRate; }

    @Override
    public String toString() {
        return String.format("%s (%s, %s) - €%.2f/h",
                lockerNumber, size, status, hourlyRate);
    }
}