package com.lockers.models;

public enum LockerStatus {
    AVAILABLE,
    OCCUPIED,
    MAINTENANCE
}
