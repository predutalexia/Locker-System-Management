package com.lockers.models;

public enum LockerSize {
    SMALL,
    MEDIUM,
    LARGE
}
