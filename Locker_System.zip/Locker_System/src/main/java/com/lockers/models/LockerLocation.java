package com.lockers.models;

import com.lockers.interfaces.Validatable;
import com.lockers.exceptions.InvalidInputException;
import java.io.Serializable;
import java.util.*;

public class LockerLocation implements Validatable, Serializable {

    private String id;
    private String name;
    private String address;
    private double latitude;
    private double longitude;
    private boolean isActive;

    private List<Locker> lockers;

    public LockerLocation(String id, String name, String address,
                          double latitude, double longitude) {

        this.id = id;
        this.name = name;
        this.address = address;
        this.latitude = latitude;
        this.longitude = longitude;
        this.isActive = true;
        this.lockers = new ArrayList<>();
    }

    public LockerLocation() {
        this.isActive = true;
        this.lockers = new ArrayList<>();
    }

    // Validation
    @Override
    public void validate() throws InvalidInputException {
        List<String> errors = getValidationErrors();
        if (!errors.isEmpty()) {
            throw new InvalidInputException(String.join("; ", errors));
        }
    }

    public List<String> getValidationErrors() {
        List<String> errors = new ArrayList<>();

        if (id == null || id.trim().isEmpty()) errors.add("Location ID cannot be empty");
        if (name == null || name.trim().isEmpty()) errors.add("Location name cannot be empty");
        if (address == null || address.trim().isEmpty()) errors.add("Address cannot be empty");

        if (latitude < -90 || latitude > 90) errors.add("Invalid latitude value");
        if (longitude < -180 || longitude > 180) errors.add("Invalid longitude value");

        Set<String> numbers = new HashSet<>();
        for (Locker locker : lockers) {
            if (!numbers.add(locker.getLockerNumber())) {
                errors.add("Duplicate locker number: " + locker.getLockerNumber());
            }
        }
        return errors;
    }

    //Locker operations
    public void addLocker(Locker locker) throws InvalidInputException {
        for (Locker l : lockers) {
            if (l.getLockerNumber().equals(locker.getLockerNumber())) {
                throw new InvalidInputException("Locker number already exists: " + locker.getLockerNumber());
            }
        }

        locker.setLocationId(this.id);
        lockers.add(locker);
    }

    public void removeLocker(String lockerId) {
        lockers.removeIf(l -> l.getId().equals(lockerId));
    }

    public List<Locker> getAvailableLockers() {
        List<Locker> list = new ArrayList<>();
        for (Locker l : lockers) {
            if (l.isAvailable()) list.add(l);
        }
        return list;
    }

    public List<Locker> getAvailableLockersBySize(LockerSize size) {
        List<Locker> list = new ArrayList<>();
        for (Locker l : lockers) {
            if (l.isAvailable() && l.getSize() == size) list.add(l);
        }
        return list;
    }

    public int getAvailableCount() {
        int count = 0;
        for (Locker l : lockers) if (l.isAvailable()) count++;
        return count;
    }

    public Locker getLockerById(String lockerId) {
        for (Locker l : lockers) if (l.getId().equals(lockerId)) return l;
        return null;
    }

    //Getters
    public String getId() { return id; }
    public String getName() { return name; }
    public String getAddress() { return address; }
    public double getLatitude() { return latitude; }
    public double getLongitude() { return longitude; }
    public boolean isActive() { return isActive; }
    public List<Locker> getLockers() { return new ArrayList<>(lockers); }

    public void setId(String id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setAddress(String address) { this.address = address; }
    public void setLatitude(double latitude) { this.latitude = latitude; }
    public void setLongitude(double longitude) { this.longitude = longitude; }
    public void setActive(boolean active) { this.isActive = active; }
    public void setLockers(List<Locker> lockers) {
        this.lockers = lockers != null ? new ArrayList<>(lockers) : new ArrayList<>();
    }

    @Override
    public String toString() {
        return name + " (" + getAvailableCount() + " available of " + lockers.size() + ")";
    }
}
