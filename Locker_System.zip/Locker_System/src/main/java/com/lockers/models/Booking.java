package com.lockers.models;

import com.lockers.interfaces.Identifiable;
import com.lockers.interfaces.Validatable;
import com.lockers.exceptions.InvalidInputException;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Random;

public class Booking implements Identifiable, Validatable {

    private String id;
    private String userName;
    private String lockerId;
    private LocalDateTime startTime;
    private LocalDateTime expectedEndTime;
    private LocalDateTime actualEndTime;
    private String accessCode;
    private double totalCost;

    public Booking(String id, String userName, String lockerId,
                   LocalDateTime startTime, int durationHours, double totalCost) {
        this.id = id;
        this.userName = userName;
        this.lockerId = lockerId;
        this.startTime = startTime;
        this.expectedEndTime = startTime.plusHours(durationHours);
        this.totalCost = totalCost;
        this.accessCode = generateAccessCode();
    }

    public Booking() {
        this.accessCode = generateAccessCode();
    }

    @Override
    public void validate() throws InvalidInputException {
        if (userName == null || userName.trim().isEmpty()) {
            throw new InvalidInputException("User name cannot be empty");
        }
        if (lockerId == null || lockerId.trim().isEmpty()) {
            throw new InvalidInputException("Locker ID cannot be empty");
        }
        if (startTime == null || expectedEndTime == null) {
            throw new InvalidInputException("Start and end time must be set");
        }
        if (expectedEndTime.isBefore(startTime)) {
            throw new InvalidInputException("End time must be after start time");
        }
        if (ChronoUnit.HOURS.between(startTime, expectedEndTime) < 1) {
            throw new InvalidInputException("Minimum booking duration is 1 hour");
        }
        if (totalCost < 0) {
            throw new InvalidInputException("Total cost cannot be negative");
        }
    }

    private String generateAccessCode() {
        Random random = new Random();
        return String.format("%06d", random.nextInt(1000000));
    }

    public boolean isActive() {
        LocalDateTime now = LocalDateTime.now();
        return now.isAfter(startTime) && now.isBefore(expectedEndTime) && actualEndTime == null;
    }

    public boolean isExpired() {
        return LocalDateTime.now().isAfter(expectedEndTime) && actualEndTime == null;
    }

    public long getRemainingHours() {
        if (actualEndTime != null) return 0;
        LocalDateTime now = LocalDateTime.now();
        if (now.isAfter(expectedEndTime)) return 0;
        return ChronoUnit.HOURS.between(now, expectedEndTime);
    }

    public void complete() {
        this.actualEndTime = LocalDateTime.now();
    }

    // Getters and Setters
    @Override
    public String getId() { return id; }

    @Override
    public void setId(String id) { this.id = id; }

    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }

    public String getLockerId() { return lockerId; }
    public void setLockerId(String lockerId) { this.lockerId = lockerId; }

    public LocalDateTime getStartTime() { return startTime; }
    public void setStartTime(LocalDateTime startTime) { this.startTime = startTime; }

    public LocalDateTime getExpectedEndTime() { return expectedEndTime; }
    public void setExpectedEndTime(LocalDateTime expectedEndTime) {
        this.expectedEndTime = expectedEndTime;
    }

    public LocalDateTime getActualEndTime() { return actualEndTime; }
    public void setActualEndTime(LocalDateTime actualEndTime) {
        this.actualEndTime = actualEndTime;
    }

    public String getAccessCode() { return accessCode; }
    public void setAccessCode(String accessCode) { this.accessCode = accessCode; }

    public double getTotalCost() { return totalCost; }
    public void setTotalCost(double totalCost) { this.totalCost = totalCost; }

    @Override
    public String toString() {
        return String.format("Booking %s: %s -> Locker %s | €%.2f | Code: %s",
                id, userName, lockerId, totalCost, accessCode);
    }
}