package com.lockers.network;

import com.lockers.services.*;
import com.lockers.repository.*;
import com.lockers.storage.*;
import com.lockers.config.AppConfig;

import java.io.*;
import java.net.*;

public class LockerServer {

    private static LocationService locationService;
    private static BookingService bookingService;

    public static void main(String[] args) {
        try {
            System.out.println("🔧 Initializing services...");
            AppConfig config = AppConfig.loadFromFile("config.properties");

            CsvStorage csvStorage = new CsvStorage(config.getDataPath());
            ObjectStreamStorage objStorage = new ObjectStreamStorage(config.getDataPath());

            LocationRepository locationRepo = new LocationRepository(csvStorage);
            LockerRepository lockerRepo = new LockerRepository(csvStorage);
            BookingRepository bookingRepo = new BookingRepository(csvStorage, objStorage);

            ValidationService validationService = new ValidationService();
            locationService = new LocationService(locationRepo, lockerRepo, validationService);
            bookingService = new BookingService(bookingRepo, lockerRepo, validationService);


            ServerSocket serverSocket = new ServerSocket(8080);
            System.out.println("Server started on port 8080");
            System.out.println("Waiting for clients...\n");


            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Connected: " + clientSocket.getInetAddress());


                new Thread(() -> handleClient(clientSocket)).start();
            }

        } catch (IOException e) {
            System.err.println("Server error: " + e.getMessage());
            e.printStackTrace();
        }
    }


    private static void handleClient(Socket socket) {
        try (
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true)
        ) {
            String request;
            while ((request = in.readLine()) != null) {
                System.out.println("Received: " + request);


                String response = processRequest(request);


                out.println(response);
                System.out.println("Sent: " + response);

                if (request.equals("EXIT")) break;
            }

            System.out.println("Client disconnected\n");

        } catch (IOException e) {
            System.err.println("Error handling client: " + e.getMessage());
        }
    }


    private static String processRequest(String request) {
        try {
            String[] parts = request.split("\\|");
            String command = parts[0];

            switch (command) {
                case "LIST_LOCATIONS":
                    return locationService.getAllLocations().stream()
                            .map(loc -> loc.getId() + ":" + loc.getName() + ":" + loc.getAddress())
                            .reduce((a, b) -> a + "," + b)
                            .orElse("NO_LOCATIONS");

                case "GET_AVAILABLE":
                    // GET_AVAILABLE|L1
                    String locationId = parts[1];
                    int count = locationService.getAvailableCount(locationId);
                    return "AVAILABLE:" + count;

                case "LIST_LOCKERS":
                    // LIST_LOCKERS|L1
                    String locId = parts[1];
                    return locationService.getLockersByLocation(locId).stream()
                            .filter(l -> l.isAvailable())
                            .map(l -> l.getId() + ":" + l.getLockerNumber() + ":" +
                                    l.getSize() + ":" + l.getHourlyRate())
                            .reduce((a, b) -> a + "," + b)
                            .orElse("NO_LOCKERS");

                case "MAKE_BOOKING":
                    // MAKE_BOOKING|userName|lockerId|hours
                    String userName = parts[1];
                    String lockerId = parts[2];
                    int hours = Integer.parseInt(parts[3]);

                    var booking = bookingService.createBooking(userName, lockerId, hours);
                    return "BOOKING_OK:" + booking.getId() + ":" +
                            booking.getAccessCode() + ":" + booking.getTotalCost();

                case "COMPLETE_BOOKING":
                    // COMPLETE_BOOKING|bookingId|accessCode
                    String bookingId = parts[1];
                    String accessCode = parts[2];

                    bookingService.completeBooking(bookingId, accessCode);
                    return "COMPLETE_OK";

                case "MY_BOOKINGS":
                    // MY_BOOKINGS|userName
                    String user = parts[1];
                    return bookingService.getBookingsByUser(user).stream()
                            .map(b -> b.getId() + ":" + b.getLockerId() + ":" +
                                    b.getTotalCost() + ":" +
                                    (b.getActualEndTime() != null ? "COMPLETED" : "ACTIVE"))
                            .reduce((a, b) -> a + "," + b)
                            .orElse("NO_BOOKINGS");

                case "EXIT":
                    return "GOODBYE";

                default:
                    return "ERROR:Unknown command: " + command;
            }

        } catch (Exception e) {
            return "ERROR:" + e.getMessage();
        }
    }
}