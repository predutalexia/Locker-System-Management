package com.lockers.network;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class LockerClient {

    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
    private Scanner scanner;

    public LockerClient() throws IOException {
        // Connect
        this.socket = new Socket("localhost", 8080);
        this.in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        this.out = new PrintWriter(socket.getOutputStream(), true);
        this.scanner = new Scanner(System.in);

        System.out.println("Connected to server!\n");
    }

    public void start() {
        boolean running = true;

        while (running) {
            printMenu();
            String choice = scanner.nextLine().trim();

            try {
                switch (choice) {
                    case "1" -> viewLocations();
                    case "2" -> viewAvailableLockers();
                    case "3" -> makeBooking();
                    case "4" -> completeBooking();
                    case "5" -> viewMyBookings();
                    case "6" -> {
                        running = false;
                        out.println("EXIT");
                        System.out.println("\nGoodbye!");
                    }
                    default -> System.out.println("Invalid option. Choose 1-6.");
                }
            } catch (IOException e) {
                System.err.println("Error: " + e.getMessage());
            }
        }

        closeConnection();
    }

    private void printMenu() {
        System.out.println("\n╔═══════════════════════════════════╗");
        System.out.println("║    LOCK-IN CLIENT SYSTEM          ║");
        System.out.println("╠═══════════════════════════════════╣");
        System.out.println("║  1. View all locations            ║");
        System.out.println("║  2. View available lockers        ║");
        System.out.println("║  3. Make a booking                ║");
        System.out.println("║  4. Complete booking              ║");
        System.out.println("║  5. View my bookings              ║");
        System.out.println("║  6. Exit                          ║");
        System.out.println("╚═══════════════════════════════════╝");
        System.out.print("Choose option: ");
    }

    private void viewLocations() throws IOException {
        // Send request to server
        out.println("LIST_LOCATIONS");

        // Read response from server
        String response = in.readLine();

        System.out.println("\nAvailable Locations:");
        System.out.println("─".repeat(60));

        if (!response.equals("NO_LOCATIONS")) {
            String[] locations = response.split(",");
            for (String loc : locations) {
                String[] parts = loc.split(":");
                System.out.printf("• %s - %s%n  Address: %s%n%n",
                        parts[0], parts[1], parts[2]);
            }
        } else {
            System.out.println("  No locations available.");
        }
    }

    private void viewAvailableLockers() throws IOException {
        System.out.print("\nEnter location ID (e.g., L1): ");
        String locationId = scanner.nextLine().trim();

        // Send request
        out.println("LIST_LOCKERS|" + locationId);

        // Read response
        String response = in.readLine();

        System.out.println("\nAvailable Lockers at " + locationId + ":");
        System.out.println("─".repeat(60));

        if (!response.equals("NO_LOCKERS")) {
            String[] lockers = response.split(",");
            for (String locker : lockers) {
                String[] parts = locker.split(":");
                System.out.printf("• %s - Number: %s, Size: %s, Rate: €%.2f/hour%n",
                        parts[0], parts[1], parts[2], Double.parseDouble(parts[3]));
            }
        } else {
            System.out.println("  No available lockers at this location.");
        }
    }

    private void makeBooking() throws IOException {
        System.out.println("\nMake a Booking");
        System.out.println("─".repeat(40));

        System.out.print("Your name: ");
        String userName = scanner.nextLine().trim();

        System.out.print("Locker ID (e.g., L1-A01): ");
        String lockerId = scanner.nextLine().trim();

        System.out.print("Duration (hours): ");
        String hours = scanner.nextLine().trim();

        // Send request
        out.println("MAKE_BOOKING|" + userName + "|" + lockerId + "|" + hours);

        // Read response
        String response = in.readLine();

        if (response.startsWith("BOOKING_OK")) {
            String[] parts = response.split(":");
            System.out.println("\nBooking created successfully!");
            System.out.println("─".repeat(60));
            System.out.println("Booking ID:   " + parts[1]);
            System.out.println("Access Code:  " + parts[2]);
            System.out.println("Total Cost:   €" + parts[3]);
            System.out.println("─".repeat(60));
            System.out.println("Keep your access code safe!");
        } else if (response.startsWith("ERROR")) {
            System.out.println(response.replace("ERROR:", ""));
        }
    }

    private void completeBooking() throws IOException {
        System.out.println("\nComplete a Booking");
        System.out.println("─".repeat(40));

        System.out.print("Booking ID: ");
        String bookingId = scanner.nextLine().trim();

        System.out.print("Access Code: ");
        String accessCode = scanner.nextLine().trim();

        // Send request
        out.println("COMPLETE_BOOKING|" + bookingId + "|" + accessCode);

        // Read response
        String response = in.readLine();

        if (response.equals("COMPLETE_OK")) {
            System.out.println("\nBooking completed successfully!");
            System.out.println("Thank you for using LOCK-IN!");
        } else if (response.startsWith("ERROR")) {
            System.out.println(response.replace("ERROR:", ""));
        }
    }

    private void viewMyBookings() throws IOException {
        System.out.print("\nYour name: ");
        String userName = scanner.nextLine().trim();

        // Send request
        out.println("MY_BOOKINGS|" + userName);

        // Read response
        String response = in.readLine();

        System.out.println("\nYour Bookings:");
        System.out.println("─".repeat(60));

        if (!response.equals("NO_BOOKINGS")) {
            String[] bookings = response.split(",");
            for (String booking : bookings) {
                String[] parts = booking.split(":");
                System.out.printf("• %s - Locker: %s | Cost: €%.2f | Status: %s%n",
                        parts[0], parts[1], Double.parseDouble(parts[2]), parts[3]);
            }
        } else {
            System.out.println("  No bookings found for " + userName);
        }
    }

    private void closeConnection() {
        try {
            if (socket != null) socket.close();
        } catch (IOException e) {
            System.err.println("Error closing connection: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        try {
            LockerClient client = new LockerClient();
            client.start();
        } catch (IOException e) {
            System.err.println("   Could not connect to server!");
            System.err.println("   Make sure the server is running first.");
            System.err.println("   Error: " + e.getMessage());
        }
    }
}
