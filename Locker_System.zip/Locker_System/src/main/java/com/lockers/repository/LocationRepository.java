package com.lockers.repository;

import com.lockers.models.LockerLocation;
import com.lockers.storage.CsvStorage;

import java.io.IOException;
import java.util.*;


public class LocationRepository {

    private final Map<String, LockerLocation> locations; // Collection: Map
    private final CsvStorage storage;

    public LocationRepository(CsvStorage storage) {
        this.storage = storage;
        this.locations = new HashMap<>();
        loadFromStorage();
    }

    private void loadFromStorage() {
        try {
            List<LockerLocation> loadedLocations = storage.loadLocations();
            for (LockerLocation loc : loadedLocations) {
                locations.put(loc.getId(), loc);
            }
        } catch (IOException e) {
            System.out.println("No existing locations found, starting fresh");
        }
    }

    public void save(LockerLocation location) throws IOException {
        locations.put(location.getId(), location);
        saveToStorage();
    }

    public LockerLocation findById(String id) {
        return locations.get(id);
    }

    public List<LockerLocation> findAll() {
        return new ArrayList<>(locations.values());
    }

    public List<LockerLocation> findByName(String namePart) {
        List<LockerLocation> result = new ArrayList<>();
        String search = namePart.toLowerCase();

        for (LockerLocation loc : locations.values()) {
            if (loc.getName().toLowerCase().contains(search)) {
                result.add(loc);
            }
        }
        return result;
    }

    public boolean exists(String id) {
        return locations.containsKey(id);
    }

    public void delete(String id) throws IOException {
        locations.remove(id);
        saveToStorage();
    }

    public int count() {
        return locations.size();
    }

    private void saveToStorage() throws IOException {
        storage.saveLocations(new ArrayList<>(locations.values()));
    }
}