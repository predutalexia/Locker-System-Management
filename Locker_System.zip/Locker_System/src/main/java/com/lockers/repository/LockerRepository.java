package com.lockers.repository;

import com.lockers.models.Locker;
import com.lockers.storage.CsvStorage;

import java.io.IOException;
import java.util.*;

public class LockerRepository {

    private final Map<String, Locker> lockers; // Collection: Map
    private final CsvStorage storage;

    public LockerRepository(CsvStorage storage) {
        this.storage = storage;
        this.lockers = new HashMap<>();
        loadFromStorage();
    }

    private void loadFromStorage() {
        try {
            List<Locker> loadedLockers = storage.loadLockers();
            for (Locker locker : loadedLockers) {
                lockers.put(locker.getId(), locker);
            }
        } catch (IOException e) {
            System.out.println("No existing lockers found, starting fresh");
        }
    }

    public void save(Locker locker) throws IOException {
        lockers.put(locker.getId(), locker);
        saveToStorage();
    }

    public Locker findById(String id) {
        return lockers.get(id);
    }

    public List<Locker> findAll() {
        return new ArrayList<>(lockers.values());
    }

    public List<Locker> findByLocationId(String locationId) {
        List<Locker> result = new ArrayList<>();
        for (Locker locker : lockers.values()) {
            if (locker.getLocationId().equals(locationId)) {
                result.add(locker);
            }
        }
        return result;
    }

    public boolean exists(String id) {
        return lockers.containsKey(id);
    }

    public void delete(String id) throws IOException {
        lockers.remove(id);
        saveToStorage();
    }

    public int count() {
        return lockers.size();
    }

    private void saveToStorage() throws IOException {
        storage.saveLockers(new ArrayList<>(lockers.values()));
    }
}
