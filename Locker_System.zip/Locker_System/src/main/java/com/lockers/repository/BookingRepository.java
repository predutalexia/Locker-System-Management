package com.lockers.repository;

import com.lockers.models.Booking;
import com.lockers.storage.CsvStorage;
import com.lockers.storage.ObjectStreamStorage;

import java.io.IOException;
import java.util.*;

public class BookingRepository {

    private final List<Booking> bookings; // Collection: List
    private final CsvStorage csvStorage;
    private final ObjectStreamStorage objStorage;

    public BookingRepository(CsvStorage csvStorage, ObjectStreamStorage objStorage) {
        this.csvStorage = csvStorage;
        this.objStorage = objStorage;
        this.bookings = new ArrayList<>();
        loadFromStorage();
    }

    private void loadFromStorage() {
        try {
            bookings.addAll(csvStorage.loadBookings());
        } catch (IOException e) {
            System.out.println("No existing bookings found, starting fresh");
        }
    }

    public void save(Booking booking) throws IOException {
        boolean found = false;
        for (int i = 0; i < bookings.size(); i++) {
            if (bookings.get(i).getId().equals(booking.getId())) {
                bookings.set(i, booking);
                found = true;
                break;
            }
        }

        if (!found) {
            bookings.add(booking);
        }

        saveToStorage();
    }

    public Booking findById(String id) {
        for (Booking booking : bookings) {
            if (booking.getId().equals(id)) {
                return booking;
            }
        }
        return null;
    }

    public List<Booking> findAll() {
        return new ArrayList<>(bookings);
    }

    public List<Booking> findByUserName(String userName) {
        List<Booking> result = new ArrayList<>();
        for (Booking booking : bookings) {
            if (booking.getUserName().equalsIgnoreCase(userName)) {
                result.add(booking);
            }
        }
        return result;
    }

    public List<Booking> findByLockerId(String lockerId) {
        List<Booking> result = new ArrayList<>();
        for (Booking booking : bookings) {
            if (booking.getLockerId().equals(lockerId)) {
                result.add(booking);
            }
        }
        return result;
    }

    public List<Booking> findActive() {
        List<Booking> result = new ArrayList<>();
        for (Booking booking : bookings) {
            if (booking.isActive()) {
                result.add(booking);
            }
        }
        return result;
    }

    public String generateNextId() {
        return "B" + (bookings.size() + 1);
    }

    public int count() {
        return bookings.size();
    }

    private void saveToStorage() throws IOException {
        csvStorage.saveBookings(bookings);
    }

    public void saveToObjectStream() throws IOException {
        objStorage.saveBookings(bookings);
    }
}