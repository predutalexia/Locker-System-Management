package com.lockers.storage;

import com.lockers.models.LockerLocation;

import java.io.*;
import java.util.List;

public class FormatComparator {

    private final String basePath;
    private final String testPath;

    public FormatComparator(String dataPath) {
        this.basePath = dataPath;
        this.testPath = dataPath + "tests/";
        createTestDirectory();
    }

    private void createTestDirectory() {
        File dir = new File(testPath);
        if (!dir.exists()) dir.mkdirs();
    }

    public void compareFormats(List<LockerLocation> locations) {
        System.out.println("\n=== CSV vs ObjectStream Comparison ===\n");

        try {
            // CSV TEST
            long csvSave = measure(() -> saveCsv(locations));
            long csvLoad = measure(this::loadCsv);
            long csvSize = getSize(testPath + "locations_test.csv");

            // OBJECT STREAM TEST
            long objSave = measure(() -> saveObject(locations));
            long objLoad = measure(this::loadObject);
            long objSize = getSize(testPath + "locations_test.dat");

            System.out.printf("CSV:          %d bytes | save %d ms | load %d ms%n",
                    csvSize, csvSave, csvLoad);

            System.out.printf("ObjectStream: %d bytes | save %d ms | load %d ms%n",
                    objSize, objSave, objLoad);

            System.out.println("\nAnalysis:");
            System.out.println("  • CSV is human-readable, portable");
            System.out.println("  • ObjectStream preserves object structure, faster load/save");

        } catch (Exception e) {
            System.err.println("Comparison failed: " + e.getMessage());
        }
    }

    private long measure(Runnable r) {
        long start = System.currentTimeMillis();
        r.run();
        return System.currentTimeMillis() - start;
    }

    private void saveCsv(List<LockerLocation> locations) {
        try (PrintWriter out = new PrintWriter(testPath + "locations_test.csv")) {
            out.println("id,name,address,latitude,longitude,isActive");
            for (LockerLocation loc : locations) {
                out.printf("%s,%s,%s,%.6f,%.6f,%b%n",
                        loc.getId(), loc.getName(), loc.getAddress(),
                        loc.getLatitude(), loc.getLongitude(), loc.isActive());
            }
        } catch (IOException ignored) {}
    }

    private void loadCsv() {
        try (BufferedReader br = new BufferedReader(
                new FileReader(testPath + "locations_test.csv"))) {
            while (br.readLine() != null) {} // just read
        } catch (IOException ignored) {}
    }

    private void saveObject(List<LockerLocation> locations) {
        try (ObjectOutputStream out = new ObjectOutputStream(
                new FileOutputStream(testPath + "locations_test.dat"))) {
            out.writeObject(locations);
        } catch (IOException ignored) {}
    }

    private void loadObject() {
        try (ObjectInputStream in = new ObjectInputStream(
                new FileInputStream(testPath + "locations_test.dat"))) {
            in.readObject();
        } catch (Exception ignored) {}
    }

    private long getSize(String file) {
        File f = new File(file);
        return f.exists() ? f.length() : 0;
    }
}
