package com.lockers.storage;

import com.lockers.models.Booking;
import com.lockers.models.LockerLocation;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;


public class ObjectStreamStorage {

    private final String dataPath;

    public ObjectStreamStorage(String dataPath) {
        this.dataPath = dataPath;
        createDataDirectory();
    }

    private void createDataDirectory() {
        try {
            Files.createDirectories(Paths.get(dataPath));
        } catch (IOException e) {
            System.err.println("Warning: Could not create data directory: " + e.getMessage());
        }
    }

    public void saveBookings(List<Booking> bookings) throws IOException {
        String filepath = dataPath + "bookings.dat";
        try (ObjectOutputStream oos = new ObjectOutputStream(
                new FileOutputStream(filepath))) {
            oos.writeObject(bookings);
        }
    }

    @SuppressWarnings("unchecked")
    public List<Booking> loadBookings() throws IOException, ClassNotFoundException {
        String filepath = dataPath + "bookings.dat";
        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream(filepath))) {
            return (List<Booking>) ois.readObject();
        } catch (FileNotFoundException e) {
            return new ArrayList<>();
        }
    }
}