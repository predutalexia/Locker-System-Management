package com.lockers.storage;

import com.lockers.models.*;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class CsvStorage {

    private final String dataPath;

    public CsvStorage(String dataPath) {
        this.dataPath = dataPath;
        createDataDirectory();
    }

    private void createDataDirectory() {
        try {
            Files.createDirectories(Paths.get(dataPath));
        } catch (IOException e) {
            System.err.println("Warning: Could not create data directory: " + e.getMessage());
        }
    }

    // Locations

    public void saveLocations(List<LockerLocation> locations) throws IOException {
        String filepath = dataPath + "locations.csv";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filepath))) {
            writer.write("id,name,address,latitude,longitude,isActive\n");
            for (LockerLocation loc : locations) {
                writer.write(String.format("%s,%s,%s,%.6f,%.6f,%b\n",
                        escapeCsv(loc.getId()),
                        escapeCsv(loc.getName()),
                        escapeCsv(loc.getAddress()),
                        loc.getLatitude(),
                        loc.getLongitude(),
                        loc.isActive()
                ));
            }
        }
    }

    public List<LockerLocation> loadLocations() throws IOException {
        String filepath = dataPath + "locations.csv";
        List<LockerLocation> locations = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filepath))) {
            String line = reader.readLine(); // skip header

            while ((line = reader.readLine()) != null) {
                try {
                    String[] parts = parseCsvLine(line);
                    if (parts.length >= 6) {
                        LockerLocation loc = new LockerLocation();
                        loc.setId(parts[0]);
                        loc.setName(parts[1]);
                        loc.setAddress(parts[2]);
                        loc.setLatitude(Double.parseDouble(parts[3]));
                        loc.setLongitude(Double.parseDouble(parts[4]));
                        loc.setActive(Boolean.parseBoolean(parts[5]));
                        locations.add(loc);
                    }
                } catch (NumberFormatException e) {
                    System.err.println("Warning: Skipping invalid location line: " + line);
                }
            }
        } catch (FileNotFoundException e) {
            // File doesn't exist yet, return empty list
            return locations;
        }

        return locations;
    }

    // Lockers

    public void saveLockers(List<Locker> lockers) throws IOException {
        String filepath = dataPath + "lockers.csv";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filepath))) {
            writer.write("id,locationId,lockerNumber,size,status,hourlyRate\n");
            for (Locker locker : lockers) {
                writer.write(String.format("%s,%s,%s,%s,%s,%.2f\n",
                        escapeCsv(locker.getId()),
                        escapeCsv(locker.getLocationId()),
                        escapeCsv(locker.getLockerNumber()),
                        locker.getSize(),
                        locker.getStatus(),
                        locker.getHourlyRate()
                ));
            }
        }
    }

    public List<Locker> loadLockers() throws IOException {
        String filepath = dataPath + "lockers.csv";
        List<Locker> lockers = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filepath))) {
            String line = reader.readLine(); // skip header

            while ((line = reader.readLine()) != null) {
                try {
                    String[] parts = parseCsvLine(line);
                    if (parts.length >= 6) {
                        Locker locker = new Locker();
                        locker.setId(parts[0]);
                        locker.setLocationId(parts[1]);
                        locker.setLockerNumber(parts[2]);
                        locker.setSize(LockerSize.valueOf(parts[3]));
                        locker.setStatus(LockerStatus.valueOf(parts[4]));
                        locker.setHourlyRate(Double.parseDouble(parts[5]));
                        lockers.add(locker);
                    }
                } catch (IllegalArgumentException e) {
                    System.err.println("Warning: Skipping invalid locker line: " + line);
                }
            }
        } catch (FileNotFoundException e) {
            return lockers;
        }

        return lockers;
    }

    // Booking

    public void saveBookings(List<Booking> bookings) throws IOException {
        String filepath = dataPath + "bookings.csv";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filepath))) {
            writer.write("id,userName,lockerId,startTime,expectedEndTime,actualEndTime,accessCode,totalCost\n");
            for (Booking booking : bookings) {
                writer.write(String.format("%s,%s,%s,%s,%s,%s,%s,%.2f\n",
                        escapeCsv(booking.getId()),
                        escapeCsv(booking.getUserName()),
                        escapeCsv(booking.getLockerId()),
                        booking.getStartTime(),
                        booking.getExpectedEndTime(),
                        booking.getActualEndTime() != null ? booking.getActualEndTime() : "",
                        escapeCsv(booking.getAccessCode()),
                        booking.getTotalCost()
                ));
            }
        }
    }

    public List<Booking> loadBookings() throws IOException {
        String filepath = dataPath + "bookings.csv";
        List<Booking> bookings = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filepath))) {
            String line = reader.readLine(); // skip header

            while ((line = reader.readLine()) != null) {
                try {
                    String[] parts = parseCsvLine(line);
                    if (parts.length >= 8) {
                        Booking booking = new Booking();
                        booking.setId(parts[0]);
                        booking.setUserName(parts[1]);
                        booking.setLockerId(parts[2]);
                        booking.setStartTime(LocalDateTime.parse(parts[3]));
                        booking.setExpectedEndTime(LocalDateTime.parse(parts[4]));
                        if (!parts[5].isEmpty()) {
                            booking.setActualEndTime(LocalDateTime.parse(parts[5]));
                        }
                        booking.setAccessCode(parts[6]);
                        booking.setTotalCost(Double.parseDouble(parts[7]));
                        bookings.add(booking);
                    }
                } catch (Exception e) {
                    System.err.println("Warning: Skipping invalid booking line: " + line);
                }
            }
        } catch (FileNotFoundException e) {
            return bookings;
        }

        return bookings;
    }

    // Utility methods

    private String escapeCsv(String value) {
        if (value == null) return "";
        if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            return "\"" + value.replace("\"", "\"\"") + "\"";
        }
        return value;
    }

    private String[] parseCsvLine(String line) {
        List<String> result = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        boolean inQuotes = false;

        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);

            if (c == '"') {
                inQuotes = !inQuotes;
            } else if (c == ',' && !inQuotes) {
                result.add(current.toString());
                current = new StringBuilder();
            } else {
                current.append(c);
            }
        }
        result.add(current.toString());

        return result.toArray(new String[0]);
    }
}