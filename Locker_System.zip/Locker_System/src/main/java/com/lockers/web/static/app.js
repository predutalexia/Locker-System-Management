const API_URL = 'http://localhost:8082/api';
let currentUser = null;
let allLocations = [];

// LOGIN
async function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if (!username || !password) {
        alert('Please fill in both fields');
        return;
    }

    try {
        const response = await fetch(`${API_URL}/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });

        const data = await response.json();

        if (data.success) {
            currentUser = { username, role: data.role };

            document.getElementById('loginSection').style.display = 'none';
            document.getElementById('appSection').style.display = 'block';

            if (data.role === 'ADMIN') {
                showAdminInterface();
            } else {
                showUserInterface();
            }
        } else {
            alert('Invalid credentials!');
        }
    } catch (error) {
        alert('Error: ' + error.message);
    }
}

// LOAD LOCATIONS DATA
async function loadLocationsData() {
    try {
        const response = await fetch(API_URL + '/locations');
        allLocations = await response.json();
        console.log('Loaded', allLocations.length, 'locations');
        return allLocations;
    } catch (error) {
        console.error('Error loading locations:', error);
        return [];
    }
}

// location name by ID
function getLocationName(locationId) {
    if (!allLocations || allLocations.length === 0) {
        return locationId;
    }

    const location = allLocations.find(loc => loc.id === locationId);
    return location ? location.name : locationId;
}

// ADMIN INTERFACE
async function showAdminInterface() {
    document.querySelector('header h1').textContent = 'LOCK-IN - Admin Panel';
    document.querySelector('header p').textContent = `Welcome, ${currentUser.username} (Administrator)`;

    document.getElementById('adminNav').style.display = 'flex';
    document.getElementById('userNav').style.display = 'none';

    await loadLocationsData();
    await loadLocations();
    await loadAllLockers();
    await loadAllBookings();

    showTab('locations');
}

// ADMIN: display all locations
async function loadLocations() {
    try {
        const container = document.getElementById('locationsList');
        if (!container) return;

        container.innerHTML = '';

        allLocations.forEach(location => {
            const card = document.createElement('div');
            card.className = 'location-card';
            card.innerHTML = `
                <h3>${location.name}</h3>
                <p><strong>ID:</strong> ${location.id}</p>
                <p><strong>Address:</strong> ${location.address}</p>
                <p><strong>Coordinates:</strong> ${location.latitude}, ${location.longitude}</p>
                <span class="badge badge-success">Active</span>
            `;
            container.appendChild(card);
        });
    } catch (error) {
        console.error('Error displaying locations:', error);
    }
}

// ADMIN: display all lockers
async function loadAllLockers() {
    try {
        const response = await fetch(API_URL + '/lockers');
        const lockers = await response.json();

        const container = document.getElementById('allLockersList');
        if (!container) return;

        container.innerHTML = '';

        lockers.forEach(locker => {
            const locationName = getLocationName(locker.locationId);
            const isAvailable = locker.status === 'AVAILABLE';
            const statusClass = isAvailable ? 'badge-success' : 'badge-info';

            const card = document.createElement('div');
            card.className = 'locker-card';
            card.innerHTML = `
                <h3>${locker.id}</h3>
                <p><strong>Location:</strong> ${locationName}</p>
                <p><strong>Number:</strong> ${locker.lockerNumber}</p>
                <p><strong>Size:</strong> ${locker.size}</p>
                <p><strong>Rate:</strong> $${locker.hourlyRate}/hour</p>
                <span class="badge ${statusClass}">${locker.status}</span>
                ${!isAvailable ? `
                    <button class="btn btn-primary" style="margin-top: 10px;" onclick="releaseLocker('${locker.id}')">
                        Release Locker
                    </button>
                ` : ''}
            `;
            container.appendChild(card);
        });
    } catch (error) {
        console.error('Error loading lockers:', error);
    }
}

// ADMIN: load all bookings
async function loadAllBookings() {
    try {
        console.log('Loading all bookings for admin...');

        const response = await fetch(`${API_URL}/all-bookings`);
        const bookings = await response.json();

        console.log('All bookings:', bookings);

        const container = document.getElementById('allBookingsList');
        if (!container) return;

        container.innerHTML = '';

        if (bookings.length === 0) {
            container.innerHTML = `
                <div class="info-box">
                    <h3>No Bookings Yet</h3>
                    <p>No bookings have been made in the system yet.</p>
                </div>
            `;
            return;
        }

        const grid = document.createElement('div');
        grid.className = 'grid';

        // summary stats at top
        const activeBookings = bookings.filter(b => !b.actualEndTime).length;
        const completedBookings = bookings.filter(b => b.actualEndTime).length;
        const totalRevenue = bookings.reduce((sum, b) => sum + b.totalCost, 0);

        const statsCard = document.createElement('div');
        statsCard.style.gridColumn = '1 / -1';
        statsCard.style.background = 'linear-gradient(135deg, #f0f5ee 0%, #faf4f6 100%)';
        statsCard.style.padding = '20px';
        statsCard.style.borderRadius = '10px';
        statsCard.style.marginBottom = '20px';
        statsCard.innerHTML = `
            <h3 style="margin-bottom: 15px; color: #6b8968;">Booking Statistics</h3>
            <div style="display: flex; gap: 30px; flex-wrap: wrap;">
                <div>
                    <p style="font-size: 0.9em; color: #666;">Total Bookings</p>
                    <p style="font-size: 1.8em; font-weight: bold; color: #6b8968;">${bookings.length}</p>
                </div>
                <div>
                    <p style="font-size: 0.9em; color: #666;">Active</p>
                    <p style="font-size: 1.8em; font-weight: bold; color: #7d9b76;">${activeBookings}</p>
                </div>
                <div>
                    <p style="font-size: 0.9em; color: #666;">Completed</p>
                    <p style="font-size: 1.8em; font-weight: bold; color: #c9a9b8;">${completedBookings}</p>
                </div>
                <div>
                    <p style="font-size: 0.9em; color: #666;">Total Revenue</p>
                    <p style="font-size: 1.8em; font-weight: bold; color: #6b8968;">$${totalRevenue.toFixed(2)}</p>
                </div>
            </div>
        `;
        grid.appendChild(statsCard);

        // display all bookings
        bookings.forEach(booking => {
            const isActive = !booking.actualEndTime;
            const statusClass = isActive ? 'badge-success' : 'badge-info';
            const statusText = isActive ? 'Active' : 'Completed';

            const locationId = booking.lockerId.split('-')[0];
            const locationName = getLocationName(locationId);

            const startDate = new Date(booking.startTime).toLocaleString();
            const endDate = booking.actualEndTime
                ? new Date(booking.actualEndTime).toLocaleString()
                : new Date(booking.expectedEndTime).toLocaleString();

            const card = document.createElement('div');
            card.className = 'locker-card';
            card.style.borderLeft = isActive ? '4px solid #7d9b76' : '4px solid #c9a9b8';
            card.innerHTML = `
                <h3>Booking ${booking.id}</h3>
                <p><strong>User:</strong> ${booking.userName}</p>
                <p><strong>Locker:</strong> ${booking.lockerId}</p>
                <p><strong>Location:</strong> ${locationName}</p>
                <p><strong>Start:</strong> ${startDate}</p>
                <p><strong>${isActive ? 'Expected End' : 'Completed'}:</strong> ${endDate}</p>
                <p><strong>Access Code:</strong> <span style="background: #f0f5ee; padding: 5px 10px; border-radius: 5px; font-family: monospace;">${booking.accessCode}</span></p>
                <p><strong>Cost:</strong> $${booking.totalCost}</p>
                <span class="badge ${statusClass}">${statusText}</span>
            `;
            grid.appendChild(card);
        });

        container.appendChild(grid);

        console.log('All bookings loaded successfully');

    } catch (error) {
        console.error('Error loading all bookings:', error);
        const container = document.getElementById('allBookingsList');
        if (container) {
            container.innerHTML = `
                <div class="info-box">
                    <h3>Error Loading Bookings</h3>
                    <p>Could not load bookings. Please try again.</p>
                </div>
            `;
        }
    }
}

// ADMIN: release an occupied locker
async function releaseLocker(lockerId) {
    if (!confirm(`Release locker ${lockerId}?`)) {
        return;
    }

    try {
        const response = await fetch(`${API_URL}/release-locker?lockerId=${lockerId}`, {
            method: 'POST'
        });

        if (!response.ok) {
            alert('Error releasing locker');
            return;
        }

        alert(`Locker ${lockerId} released!`);
        await loadAllLockers();

    } catch (error) {
        alert('Error: ' + error.message);
    }
}

// USER INTERFACE
async function showUserInterface() {
    document.querySelector('header h1').textContent = 'LOCK-IN - Book a Locker';
    document.querySelector('header p').textContent = `Welcome, ${currentUser.username}`;

    document.getElementById('userNav').style.display = 'flex';
    document.getElementById('adminNav').style.display = 'none';

    await loadLocationsData();
    await loadAvailableLockers();
    await loadMyBookings();

    showTab('available');
}

// USER: display available lockers
async function loadAvailableLockers() {
    try {
        const response = await fetch(API_URL + '/lockers');
        const allLockers = await response.json();

        const available = allLockers.filter(locker => locker.status === 'AVAILABLE');

        const container = document.getElementById('availableLockersList');
        if (!container) return;

        container.innerHTML = '';

        if (available.length === 0) {
            container.innerHTML = '<div class="info-box"><h3>No Available Lockers</h3><p>All lockers are currently occupied.</p></div>';
            return;
        }

        const byLocation = {};
        available.forEach(locker => {
            if (!byLocation[locker.locationId]) {
                byLocation[locker.locationId] = [];
            }
            byLocation[locker.locationId].push(locker);
        });

        Object.keys(byLocation).forEach(locationId => {
            const locationName = getLocationName(locationId);
            const lockersHere = byLocation[locationId];

            // location header
            const locationHeader = document.createElement('div');
            locationHeader.style.gridColumn = '1 / -1';
            locationHeader.innerHTML = `
                <h3 style="color: #6b8968; margin: 20px 0 10px; padding-bottom: 10px; border-bottom: 2px solid #e3d5d9;">
                    ${locationName} (${lockersHere.length} available)
                </h3>
            `;
            container.appendChild(locationHeader);

            // locker cards
            lockersHere.forEach(locker => {
                const card = document.createElement('div');
                card.className = 'locker-card';
                card.innerHTML = `
                    <h3>Locker ${locker.lockerNumber}</h3>
                    <p><strong>Size:</strong> ${locker.size}</p>
                    <p><strong>Rate:</strong> $${locker.hourlyRate}/hour</p>
                    <button class="btn btn-success" onclick="selectLocker('${locker.id}', '${locationName}')">
                        Book Now
                    </button>
                `;
                container.appendChild(card);
            });
        });

    } catch (error) {
        console.error('Error loading available lockers:', error);
    }
}

// USER: display my bookings
async function loadMyBookings() {
    try {
        const url = `${API_URL}/user-bookings?username=${currentUser.username}`;
        const response = await fetch(url);

        if (!response.ok) {
            console.error('Failed to fetch bookings');
            return;
        }

        const bookings = await response.json();

        let container = document.getElementById('myBookingsList');

        if (!container) {
            const tab = document.getElementById('myBookingsTab');
            tab.innerHTML = '<h2>My Bookings</h2>';

            container = document.createElement('div');
            container.id = 'myBookingsList';
            container.className = 'grid';
            tab.appendChild(container);
        }

        container.innerHTML = '';

        if (bookings.length === 0) {
            container.innerHTML = `
                <div class="info-box">
                    <h3>No Bookings Yet</h3>
                    <p>You haven't made any bookings yet.</p>
                    <p>Go to "Available Lockers" to book one!</p>
                </div>
            `;
            return;
        }

        bookings.forEach(booking => {
            const isActive = !booking.actualEndTime;
            const statusClass = isActive ? 'badge-success' : 'badge-info';
            const statusText = isActive ? 'Active' : 'Completed';

            const locationId = booking.lockerId.split('-')[0];
            const locationName = getLocationName(locationId);

            const startDate = new Date(booking.startTime).toLocaleString();

            const card = document.createElement('div');
            card.className = 'locker-card';
            card.innerHTML = `
                <h3>Booking ${booking.id}</h3>
                <p><strong>Locker:</strong> ${booking.lockerId}</p>
                <p><strong>Location:</strong> ${locationName}</p>
                <p><strong>Start:</strong> ${startDate}</p>
                <p><strong>Access Code:</strong> <span style="background: #f0f5ee; padding: 5px 10px; border-radius: 5px; font-weight: bold;">${booking.accessCode}</span></p>
                <p><strong>Total Cost:</strong> $${booking.totalCost}</p>
                <span class="badge ${statusClass}">${statusText}</span>
            `;
            container.appendChild(card);
        });

    } catch (error) {
        console.error('Error loading my bookings:', error);
    }
}

function selectLocker(lockerId, locationName) {
    document.getElementById('bookingLocker').value = lockerId;

    const bookingCard = document.querySelector('#bookingTab .card');
    let hint = bookingCard.querySelector('.selection-hint');

    if (!hint) {
        hint = document.createElement('p');
        hint.className = 'selection-hint';
        hint.style.color = '#6b8968';
        hint.style.background = '#f0f5ee';
        hint.style.padding = '10px';
        hint.style.borderRadius = '8px';
        hint.style.marginBottom = '15px';
        hint.style.textAlign = 'center';
        hint.style.fontWeight = 'bold';
        bookingCard.insertBefore(hint, bookingCard.children[1]);
    }

    hint.textContent = `Selected: ${lockerId} at ${locationName}`;

    showTab('booking');
}

// make booking
async function makeBooking() {
    const lockerId = document.getElementById('bookingLocker').value;
    const hours = document.getElementById('bookingHours').value;

    const userName = currentUser.username;

    if (!lockerId || !hours) {
        alert('Please fill all fields!');
        return;
    }

    try {
        const response = await fetch(`${API_URL}/bookings`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                userName,
                lockerId,
                hours: parseInt(hours)
            })
        });

        const booking = await response.json();

        if (booking.error) {
            alert('Error: ' + booking.error);
            return;
        }

        const result = document.getElementById('bookingResult');
        result.className = 'success';
        result.innerHTML = `
            <h3>Booking Created Successfully!</h3>
            <p><strong>Booking ID:</strong> ${booking.id}</p>
            <p><strong>Access Code:</strong> ${booking.accessCode}</p>
            <p><strong>Total Cost:</strong> $${booking.totalCost}</p>
            <p style="color: #e63946; font-weight: bold; margin-top: 10px;">
                IMPORTANT: SAVE YOUR ACCESS CODE!
            </p>
        `;

        // clear
        document.getElementById('bookingLocker').value = '';
        document.getElementById('bookingHours').value = '';

        const hint = document.querySelector('.selection-hint');
        if (hint) hint.remove();

        // reload
        setTimeout(async () => {
            await loadAvailableLockers();
            await loadMyBookings();
        }, 500);

    } catch (error) {
        const result = document.getElementById('bookingResult');
        result.className = 'error';
        result.innerHTML = `<p>Error: ${error.message}</p>`;
    }
}

// TAB SWITCHING
function showTab(tabName) {
    if (tabName === 'logout') {
        logout();
        return;
    }

    if (tabName === 'myBookings' && currentUser) {
        loadMyBookings();
    }

    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.style.display = 'none';
    });

    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });

    const tabElement = document.getElementById(tabName + 'Tab');
    if (tabElement) {
        tabElement.style.display = 'block';
    }

    document.querySelectorAll('.tab-btn').forEach(btn => {
        const onclickAttr = btn.getAttribute('onclick');
        if (onclickAttr && onclickAttr.includes(`'${tabName}'`)) {
            btn.classList.add('active');
        }
    });
}

// LOGOUT
function logout() {
    currentUser = null;
    allLocations = [];
    document.getElementById('appSection').style.display = 'none';
    document.getElementById('loginSection').style.display = 'block';
    document.getElementById('adminNav').style.display = 'none';
    document.getElementById('userNav').style.display = 'none';
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
}

// ENTER KEY TO LOGIN
document.addEventListener('DOMContentLoaded', function() {
    const inputs = document.querySelectorAll('#loginSection input');
    inputs.forEach(input => {
        input.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                login();
            }
        });
    });
});