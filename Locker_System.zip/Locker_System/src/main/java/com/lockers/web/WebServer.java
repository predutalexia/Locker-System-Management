package com.lockers.web;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;

import com.lockers.db.DatabaseService;
import com.lockers.models.*;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.sql.SQLException;
import java.util.List;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonSerializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.lang.reflect.Type;
import java.time.LocalDateTime;

import com.google.gson.Gson;

public class WebServer {

    private static DatabaseService dbService = new DatabaseService();
    private static Gson gson = new GsonBuilder()
            .registerTypeAdapter(LocalDateTime.class, new JsonSerializer<LocalDateTime>() {
                @Override
                public JsonElement serialize(LocalDateTime src, Type typeOfSrc, JsonSerializationContext context) {
                    return new JsonPrimitive(src.toString());
                }
            })
            .create();

    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(8082), 0);

        server.createContext("/", new StaticFileHandler());
        server.createContext("/api/locations", new LocationsHandler());
        server.createContext("/api/lockers", new LockersHandler());
        server.createContext("/api/bookings", new BookingsHandler());
        server.createContext("/api/user-bookings", new UserBookingsHandler());
        server.createContext("/api/all-bookings", new AllBookingsHandler());
        server.createContext("/api/release-locker", new ReleaseLockersHandler());
        server.createContext("/api/login", new LoginHandler());

        server.setExecutor(null);
        server.start();

        System.out.println("Web Server started at http://localhost:8082");
    }

    static class StaticFileHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String path = exchange.getRequestURI().getPath();
            if (path.equals("/")) path = "/index.html";

            String basePath = System.getProperty("user.dir");
            File file = new File(basePath + "/src/main/java/com/lockers/web/static" + path);

            if (file.exists() && file.isFile() && file.canRead()) {
                String contentType = getContentType(path);
                exchange.getResponseHeaders().set("Content-Type", contentType);
                byte[] bytes = Files.readAllBytes(file.toPath());
                exchange.sendResponseHeaders(200, bytes.length);
                OutputStream os = exchange.getResponseBody();
                os.write(bytes);
                os.close();
            } else {
                String response = "404 - Not Found";
                exchange.sendResponseHeaders(404, response.length());
                exchange.getResponseBody().write(response.getBytes());
                exchange.getResponseBody().close();
            }
        }

        private String getContentType(String path) {
            if (path.endsWith(".html")) return "text/html; charset=UTF-8";
            if (path.endsWith(".css")) return "text/css; charset=UTF-8";
            if (path.endsWith(".js")) return "application/javascript; charset=UTF-8";
            return "text/plain";
        }
    }

    static class LocationsHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equals(exchange.getRequestMethod())) {
                try {
                    List<LockerLocation> locations = dbService.getAllLocations();

                    String json = gson.toJson(locations);
                    sendJsonResponse(exchange, json);
                } catch (SQLException e) {
                    sendError(exchange, "Database error: " + e.getMessage());
                }
            }
        }
    }

    static class LockersHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equals(exchange.getRequestMethod())) {
                try {
                    // get lockers, available and occupied
                    List<Locker> lockers = dbService.getAllLockers();

                    String json = gson.toJson(lockers);
                    sendJsonResponse(exchange, json);
                } catch (SQLException e) {
                    sendError(exchange, "Database error: " + e.getMessage());
                }
            }
        }
    }

    static class BookingsHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("POST".equals(exchange.getRequestMethod())) {
                try {
                    InputStreamReader isr = new InputStreamReader(exchange.getRequestBody());
                    BufferedReader br = new BufferedReader(isr);
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    String body = sb.toString();

                    String userName = extractValue(body, "userName");
                    String lockerId = extractValue(body, "lockerId");
                    int hours = Integer.parseInt(extractValue(body, "hours"));

                    Booking booking = new Booking(
                            "B" + System.currentTimeMillis(),
                            userName,
                            lockerId,
                            java.time.LocalDateTime.now(),
                            hours,
                            hours * 10.0
                    );

                    dbService.saveBooking(booking);
                    dbService.updateLockerStatus(lockerId, LockerStatus.OCCUPIED);

                    sendJsonResponse(exchange, gson.toJson(booking));
                } catch (Exception e) {
                    sendError(exchange, "Error: " + e.getMessage());
                }
            }
        }

        private String extractValue(String json, String key) {
            String search = "\"" + key + "\":\"";
            int start = json.indexOf(search);
            if (start == -1) {
                search = "\"" + key + "\":";
                start = json.indexOf(search);
                if (start == -1) return "";
                start += search.length();
                int end = json.indexOf(",", start);
                if (end == -1) end = json.indexOf("}", start);
                return json.substring(start, end).trim();
            }
            start += search.length();
            int end = json.indexOf("\"", start);
            return json.substring(start, end);
        }
    }

    static class ReleaseLockersHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("POST".equals(exchange.getRequestMethod())) {
                try {
                    String query = exchange.getRequestURI().getQuery();
                    String lockerId = null;

                    if (query != null && query.startsWith("lockerId=")) {
                        lockerId = query.substring("lockerId=".length());
                    }

                    if (lockerId == null || lockerId.isEmpty()) {
                        sendError(exchange, "Locker ID required");
                        return;
                    }

                    // update locker status
                    dbService.updateLockerStatus(lockerId, LockerStatus.AVAILABLE);

                    String json = "{\"success\":true}";
                    sendJsonResponse(exchange, json);

                } catch (Exception e) {
                    sendError(exchange, "Error: " + e.getMessage());
                }
            }
        }
    }

    static class LoginHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("POST".equals(exchange.getRequestMethod())) {
                InputStreamReader isr = new InputStreamReader(exchange.getRequestBody());
                BufferedReader br = new BufferedReader(isr);
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                String body = sb.toString();

                String username = extractValue(body, "username");
                String password = extractValue(body, "password");

                try {
                    String role = dbService.authenticateUser(username, password);
                    String json = (role != null)
                            ? "{\"success\":true,\"role\":\"" + role + "\"}"
                            : "{\"success\":false,\"message\":\"Invalid credentials\"}";
                    sendJsonResponse(exchange, json);
                } catch (SQLException e) {
                    sendError(exchange, "Database error");
                }
            }
        }

        private String extractValue(String json, String key) {
            String search = "\"" + key + "\":\"";
            int start = json.indexOf(search) + search.length();
            int end = json.indexOf("\"", start);
            return json.substring(start, end);
        }
    }


    static class UserBookingsHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equals(exchange.getRequestMethod())) {
                try {
                    // get username from query parameter
                    String query = exchange.getRequestURI().getQuery();
                    String username = null;

                    if (query != null && query.startsWith("username=")) {
                        username = query.substring("username=".length());
                    }

                    if (username == null || username.isEmpty()) {
                        sendError(exchange, "Username required");
                        return;
                    }

                    List<Booking> bookings = dbService.getUserBookings(username);
                    String json = gson.toJson(bookings);
                    sendJsonResponse(exchange, json);

                } catch (SQLException e) {
                    sendError(exchange, "Database error: " + e.getMessage());
                }
            }
        }
    }

    static class AllBookingsHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equals(exchange.getRequestMethod())) {
                try {
                    List<Booking> bookings = dbService.getAllBookings();
                    String json = gson.toJson(bookings);
                    sendJsonResponse(exchange, json);
                } catch (SQLException e) {
                    sendError(exchange, "Database error: " + e.getMessage());
                }
            }
        }
    }

    private static void sendJsonResponse(HttpExchange exchange, String json) throws IOException {
        byte[] bytes = json.getBytes("UTF-8");
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.sendResponseHeaders(200, bytes.length);
        OutputStream os = exchange.getResponseBody();
        os.write(bytes);
        os.close();
    }


    private static void sendError(HttpExchange exchange, String message) throws IOException {
        String json = "{\"error\":\"" + message + "\"}";
        byte[] bytes = json.getBytes("UTF-8");
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        exchange.sendResponseHeaders(500, bytes.length);
        exchange.getResponseBody().write(bytes);
        exchange.getResponseBody().close();
    }
}