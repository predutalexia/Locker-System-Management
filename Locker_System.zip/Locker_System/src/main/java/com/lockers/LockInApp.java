package com.lockers;

import com.lockers.config.AppConfig;
import com.lockers.services.*;
import com.lockers.repository.*;
import com.lockers.storage.*;
import com.lockers.exceptions.InvalidInputException;

import java.io.IOException;

public class LockInApp {

    public static void main(String[] args) {
        if (args.length == 0) {
            printUsage();
            return;
        }

        String mode = args[0].toLowerCase();

        try {
            switch (mode) {
                case "server" -> startServer();
                case "client" -> startClient();
                case "demo" -> loadDemoAndStartServer();
                default -> {
                    System.out.println("Invalid mode: " + mode);
                    printUsage();
                }
            }
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void startServer() {
        System.out.println("Starting LOCK-IN Server...");
        com.lockers.network.LockerServer.main(new String[]{});
    }

    private static void startClient() {
        System.out.println("Starting LOCK-IN Client...");
        com.lockers.network.LockerClient.main(new String[]{});
    }

    private static void loadDemoAndStartServer() throws IOException, InvalidInputException {
        System.out.println("Loading demo data...");

        AppConfig config = AppConfig.loadFromFile("config.properties");

        CsvStorage csvStorage = new CsvStorage(config.getDataPath());
        ObjectStreamStorage objStorage = new ObjectStreamStorage(config.getDataPath());

        LocationRepository locationRepo = new LocationRepository(csvStorage);
        LockerRepository lockerRepo = new LockerRepository(csvStorage);
        BookingRepository bookingRepo = new BookingRepository(csvStorage, objStorage);

        ValidationService validationService = new ValidationService();
        LocationService locationService = new LocationService(
                locationRepo, lockerRepo, validationService
        );

        loadDemoData(locationService);

        System.out.println("Demo data loaded!");
        System.out.println();

        startServer();
    }

    private static void loadDemoData(LocationService locationService)
            throws InvalidInputException, IOException {

        locationService.createLocation(
                "L1", "Train Station", "Main Street 1", 45.75, 21.23
        );
        locationService.createLocation(
                "L2", "City Center", "Central Square 10", 45.76, 21.24
        );
        locationService.createLocation(
                "L3", "Shopping Mall", "Mall Avenue 5", 45.74, 21.25
        );

        // Add lockers to Train Station
        locationService.addLockerToLocation("L1", "A01", "SMALL", 5.0);
        locationService.addLockerToLocation("L1", "A02", "SMALL", 5.0);
        locationService.addLockerToLocation("L1", "A03", "MEDIUM", 7.5);
        locationService.addLockerToLocation("L1", "A04", "LARGE", 10.0);

        // Add lockers to City Center
        locationService.addLockerToLocation("L2", "B01", "SMALL", 6.0);
        locationService.addLockerToLocation("L2", "B02", "MEDIUM", 8.0);
        locationService.addLockerToLocation("L2", "B03", "LARGE", 11.0);

        // Add lockers to Shopping Mall
        locationService.addLockerToLocation("L3", "C01", "MEDIUM", 7.0);
        locationService.addLockerToLocation("L3", "C02", "LARGE", 9.5);
    }

    private static void printUsage() {
        System.out.println("╔════════════════════════════════════════════╗");
        System.out.println("║     LOCK-IN Locker Management System       ║");
        System.out.println("╠════════════════════════════════════════════╣");
        System.out.println("║  1. Load Demo Data + Start Server:         ║");
        System.out.println("║     java LockInApp demo                    ║");
        System.out.println("║                                            ║");
        System.out.println("║  2. Start Server:                          ║");
        System.out.println("║     java LockInApp server                  ║");
        System.out.println("║                                            ║");
        System.out.println("║  3. Start Client:                          ║");
        System.out.println("║     java LockInApp client                  ║");
        System.out.println("╚════════════════════════════════════════════╝");
    }
}