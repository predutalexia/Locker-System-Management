package com.lockers.db;

import com.lockers.models.*;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class DatabaseService {

    // lockers from DB
    public List<Locker> getAllLockers() throws SQLException {
        List<Locker> lockers = new ArrayList<>();
        String sql = "SELECT * FROM lockers";

        try (Connection conn = DB_Connection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Locker locker = new Locker();
                locker.setId(rs.getString("id"));
                locker.setLocationId(rs.getString("location_id"));
                locker.setLockerNumber(rs.getString("locker_number"));
                locker.setSize(LockerSize.valueOf(rs.getString("size")));
                locker.setStatus(LockerStatus.valueOf(rs.getString("status")));
                locker.setHourlyRate(rs.getDouble("hourly_rate"));
                lockers.add(locker);
            }
        }

        return lockers;
    }

    // available lockers from DB
    public List<Locker> getAvailableLockers() throws SQLException {
        List<Locker> lockers = new ArrayList<>();
        String sql = "SELECT * FROM lockers WHERE status = 'AVAILABLE'";

        try (Connection conn = DB_Connection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Locker locker = new Locker();
                locker.setId(rs.getString("id"));
                locker.setLocationId(rs.getString("location_id"));
                locker.setLockerNumber(rs.getString("locker_number"));
                locker.setSize(LockerSize.valueOf(rs.getString("size")));
                locker.setStatus(LockerStatus.valueOf(rs.getString("status")));
                locker.setHourlyRate(rs.getDouble("hourly_rate"));
                lockers.add(locker);
            }
        }

        return lockers;
    }

    // all locations from DB
    public List<LockerLocation> getAllLocations() throws SQLException {
        List<LockerLocation> locations = new ArrayList<>();
        String sql = "SELECT * FROM locker_locations WHERE is_active = TRUE";

        try (Connection conn = DB_Connection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                LockerLocation loc = new LockerLocation();
                loc.setId(rs.getString("id"));
                loc.setName(rs.getString("name"));
                loc.setAddress(rs.getString("address"));
                loc.setLatitude(rs.getDouble("latitude"));
                loc.setLongitude(rs.getDouble("longitude"));
                loc.setActive(rs.getBoolean("is_active"));
                locations.add(loc);
            }
        }

        return locations;
    }

    // get bookings for user
    public List<Booking> getUserBookings(String username) throws SQLException {
        List<Booking> bookings = new ArrayList<>();
        String sql = "SELECT * FROM bookings WHERE user_name = ? ORDER BY start_time DESC";

        try (Connection conn = DB_Connection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Booking booking = new Booking();
                    booking.setId(rs.getString("id"));
                    booking.setUserName(rs.getString("user_name"));
                    booking.setLockerId(rs.getString("locker_id"));
                    booking.setStartTime(rs.getTimestamp("start_time").toLocalDateTime());
                    booking.setExpectedEndTime(rs.getTimestamp("expected_end_time").toLocalDateTime());

                    Timestamp actualEnd = rs.getTimestamp("actual_end_time");
                    if (actualEnd != null) {
                        booking.setActualEndTime(actualEnd.toLocalDateTime());
                    }

                    booking.setAccessCode(rs.getString("access_code"));
                    booking.setTotalCost(rs.getDouble("total_cost"));

                    bookings.add(booking);
                }
            }
        }

        return bookings;
    }

    // insert a new booking into DB
    public void saveBooking(Booking booking) throws SQLException {
        String sql = """
            INSERT INTO bookings 
            (id, user_name, locker_id, start_time, expected_end_time, 
             actual_end_time, access_code, total_cost)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """;

        try (Connection conn = DB_Connection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, booking.getId());
            pstmt.setString(2, booking.getUserName());
            pstmt.setString(3, booking.getLockerId());
            pstmt.setTimestamp(4, Timestamp.valueOf(booking.getStartTime()));
            pstmt.setTimestamp(5, Timestamp.valueOf(booking.getExpectedEndTime()));

            if (booking.getActualEndTime() != null) {
                pstmt.setTimestamp(6, Timestamp.valueOf(booking.getActualEndTime()));
            } else {
                pstmt.setNull(6, Types.TIMESTAMP);
            }

            pstmt.setString(7, booking.getAccessCode());
            pstmt.setDouble(8, booking.getTotalCost());

            pstmt.executeUpdate();
            System.out.println("Booking saved to database: " + booking.getId());
        }
    }

    // ADMIN: get ALL bookings
    public List<Booking> getAllBookings() throws SQLException {
        List<Booking> bookings = new ArrayList<>();
        String sql = "SELECT * FROM bookings ORDER BY start_time DESC";

        try (Connection conn = DB_Connection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Booking booking = new Booking();
                booking.setId(rs.getString("id"));
                booking.setUserName(rs.getString("user_name"));
                booking.setLockerId(rs.getString("locker_id"));
                booking.setStartTime(rs.getTimestamp("start_time").toLocalDateTime());
                booking.setExpectedEndTime(rs.getTimestamp("expected_end_time").toLocalDateTime());

                Timestamp actualEnd = rs.getTimestamp("actual_end_time");
                if (actualEnd != null) {
                    booking.setActualEndTime(actualEnd.toLocalDateTime());
                }

                booking.setAccessCode(rs.getString("access_code"));
                booking.setTotalCost(rs.getDouble("total_cost"));

                bookings.add(booking);
            }
        }

        return bookings;
    }

    // update booking
    public void updateBooking(Booking booking) throws SQLException {
        String sql = """
            UPDATE bookings 
            SET actual_end_time = ?
            WHERE id = ?
            """;

        try (Connection conn = DB_Connection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setTimestamp(1, Timestamp.valueOf(booking.getActualEndTime()));
            pstmt.setString(2, booking.getId());

            pstmt.executeUpdate();
            System.out.println("Booking updated in database: " + booking.getId());
        }
    }

    // locker status
    public void updateLockerStatus(String lockerId, LockerStatus status) throws SQLException {
        String sql = "UPDATE lockers SET status = ? WHERE id = ?";

        try (Connection conn = DB_Connection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, status.toString());
            pstmt.setString(2, lockerId);

            pstmt.executeUpdate();
            System.out.println("Locker status updated: " + lockerId + " -> " + status);
        }
    }

    // authenticate user
    public String authenticateUser(String username, String password) throws SQLException {
        String sql = "SELECT role FROM users WHERE username = ? AND password = ?";

        try (Connection conn = DB_Connection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username);
            pstmt.setString(2, password);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    // Returns admin or user
                    return rs.getString("role");
                }
            }
        }

        return null;
    }

    // test all methods
    public static void main(String[] args) {
        DatabaseService dbService = new DatabaseService();

        try {
            System.out.println("Testing QUERY - Getting all locations:");
            List<LockerLocation> locations = dbService.getAllLocations();
            for (LockerLocation loc : locations) {
                System.out.println("  • " + loc.getName() + " - " + loc.getAddress());
            }

            System.out.println("\nTesting QUERY - Getting available lockers:");
            List<Locker> lockers = dbService.getAvailableLockers();
            for (Locker locker : lockers) {
                System.out.println("  • " + locker.getId() + " - " + locker.getSize());
            }

            // test insert
            System.out.println("\nTesting INSERT - Creating a booking:");
            Booking testBooking = new Booking(
                    "B999",
                    "Test User",
                    "L1-A01",
                    LocalDateTime.now(),
                    2,
                    10.0
            );
            dbService.saveBooking(testBooking);

            // test update
            System.out.println("\nTesting UPDATE - Marking locker as occupied:");
            dbService.updateLockerStatus("L1-A01", LockerStatus.OCCUPIED);

            // test authentication
            System.out.println("\nTesting AUTHENTICATION:");
            String role = dbService.authenticateUser("admin", "admin123");
            if (role != null) {
                System.out.println("Login successful! Role: " + role);
            } else {
                System.out.println("Login failed!");
            }

            System.out.println("\nAll database operations successful!");

        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}