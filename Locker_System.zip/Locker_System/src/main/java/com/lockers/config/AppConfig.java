package com.lockers.config;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class AppConfig {

    private final String dataPath;

    private AppConfig(Properties props) {
        this.dataPath = props.getProperty("data.path", "data/");
    }

    public static AppConfig loadFromFile(String filename) throws IOException {
        Properties props = new Properties();

        try (FileInputStream fis = new FileInputStream(filename)) {
            props.load(fis);
            System.out.println(" Configuration loaded from " + filename);
            return new AppConfig(props);
        } catch (FileNotFoundException e) {
            System.out.println(" Config file not found, using default settings");
            return new AppConfig(new Properties());
        }
    }

    public String getDataPath() {
        return dataPath.endsWith("/") ? dataPath : dataPath + "/";
    }
}