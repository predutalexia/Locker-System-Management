package com.lockers.interfaces;

public interface Identifiable {
    String getId();

    void setId(String id);
}