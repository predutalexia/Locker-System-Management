package com.lockers.interfaces;

import com.lockers.exceptions.InvalidInputException;

public interface Validatable {
    void validate() throws InvalidInputException;
}