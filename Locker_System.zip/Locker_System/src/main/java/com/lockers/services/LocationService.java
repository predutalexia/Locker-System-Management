package com.lockers.services;

import com.lockers.exceptions.InvalidInputException;
import com.lockers.models.*;
import com.lockers.repository.LocationRepository;
import com.lockers.repository.LockerRepository;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class LocationService {

    private final LocationRepository locationRepo;
    private final LockerRepository lockerRepo;
    private final ValidationService validator;

    public LocationService(LocationRepository locationRepo,
                           LockerRepository lockerRepo,
                           ValidationService validator) {
        this.locationRepo = locationRepo;
        this.lockerRepo = lockerRepo;
        this.validator = validator;
    }


    public void createLocation(String id, String name, String address,
                               double latitude, double longitude)
            throws InvalidInputException, IOException {

        validator.validateNotEmpty(id, "Location ID");
        validator.validateNotEmpty(name, "Location name");
        validator.validateNotEmpty(address, "Address");
        validator.validateLatitude(latitude);
        validator.validateLongitude(longitude);

        LockerLocation location = new LockerLocation(id, name, address, latitude, longitude);
        location.validate();

        locationRepo.save(location);
    }

    public List<LockerLocation> getAllLocations() {
        return locationRepo.findAll();
    }

    public LockerLocation getLocationById(String id) {
        return locationRepo.findById(id);
    }


    public void addLockerToLocation(String locationId, String number,
                                    String sizeStr, double hourlyRate)
            throws InvalidInputException, IOException {

        validator.validateNotEmpty(number, "Locker number");
        validator.validatePositive(hourlyRate, "Hourly rate");

        LockerLocation location = locationRepo.findById(locationId);
        if (location == null)
            throw new InvalidInputException("Location not found: " + locationId);

        LockerSize size = validator.validateAndParseSize(sizeStr);

        Locker locker = new Locker(locationId, number, size, hourlyRate);
        locker.validate();

        location.addLocker(locker);
        location.validate();

        // Save lockers and the location state
        lockerRepo.save(locker);
        locationRepo.save(location);
    }

    public List<Locker> getLockersByLocation(String locationId) {
        return lockerRepo.findByLocationId(locationId);
    }

    public int getAvailableCount(String locationId) {
        LockerLocation loc = locationRepo.findById(locationId);
        return (loc != null) ? loc.getAvailableCount() : 0;
    }

    public List<Locker> getAvailableLockers() {
        List<Locker> all = lockerRepo.findAll();
        List<Locker> available = new ArrayList<>();
        for (Locker l : all)
            if (l.isAvailable()) available.add(l);
        return available;
    }

    public List<Locker> searchAvailableLockers(String locationName, LockerSize size) {
        List<LockerLocation> locations = locationRepo.findByName(locationName);
        List<Locker> result = new ArrayList<>();

        for (LockerLocation loc : locations) {
            for (Locker locker : lockerRepo.findByLocationId(loc.getId())) {
                if (locker.isAvailable() && locker.getSize() == size) {
                    result.add(locker);
                }
            }
        }
        return result;
    }
}
