package com.lockers.services;

import com.lockers.exceptions.InvalidInputException;
import com.lockers.models.LockerSize;

public class ValidationService {

    public void validateNotEmpty(String value, String fieldName) throws InvalidInputException {
        if (value == null || value.trim().isEmpty()) {
            throw new InvalidInputException(fieldName + " cannot be empty");
        }
    }

    public void validatePositive(double value, String fieldName) throws InvalidInputException {
        if (value <= 0) {
            throw new InvalidInputException(fieldName + " must be positive");
        }
    }

    public void validatePositiveInt(int value, String fieldName) throws InvalidInputException {
        if (value <= 0) {
            throw new InvalidInputException(fieldName + " must be positive");
        }
    }

    public void validateLatitude(double latitude) throws InvalidInputException {
        if (latitude < -90 || latitude > 90) {
            throw new InvalidInputException("Latitude must be between -90 and 90");
        }
    }

    public void validateLongitude(double longitude) throws InvalidInputException {
        if (longitude < -180 || longitude > 180) {
            throw new InvalidInputException("Longitude must be between -180 and 180");
        }
    }

    public LockerSize validateAndParseSize(String sizeStr) throws InvalidInputException {
        try {
            return LockerSize.valueOf(sizeStr.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new InvalidInputException("Invalid size. Must be SMALL, MEDIUM, or LARGE");
        }
    }

    public double validateAndParseDouble(String value, String fieldName)
            throws InvalidInputException {
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException e) {
            throw new InvalidInputException(fieldName + " must be a valid number");
        }
    }

    public int validateAndParseInt(String value, String fieldName)
            throws InvalidInputException {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            throw new InvalidInputException(fieldName + " must be a valid integer");
        }
    }
}