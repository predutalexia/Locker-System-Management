package com.lockers.services;

import com.lockers.exceptions.InvalidInputException;
import com.lockers.exceptions.LockerNotAvailableException;
import com.lockers.models.Booking;
import com.lockers.models.Locker;
import com.lockers.repository.BookingRepository;
import com.lockers.repository.LockerRepository;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

public class BookingService {

    private final BookingRepository bookingRepo;
    private final LockerRepository lockerRepo;
    private final ValidationService validator;

    public BookingService(BookingRepository bookingRepo,
                          LockerRepository lockerRepo,
                          ValidationService validator) {
        this.bookingRepo = bookingRepo;
        this.lockerRepo = lockerRepo;
        this.validator = validator;
    }

    public Booking createBooking(String userName, String lockerId, int durationHours)
            throws InvalidInputException, LockerNotAvailableException, IOException {

        // Validate inputs
        validator.validateNotEmpty(userName, "User name");
        validator.validateNotEmpty(lockerId, "Locker ID");
        validator.validatePositiveInt(durationHours, "Duration");

        // Find locker
        Locker locker = lockerRepo.findById(lockerId);
        if (locker == null) {
            throw new InvalidInputException("Locker not found: " + lockerId);
        }

        // Check availability
        if (!locker.isAvailable()) {
            throw new LockerNotAvailableException(
                    "Locker " + lockerId + " is not available");
        }

        // Calculate cost
        double totalCost = locker.calculateCost(durationHours);

        // Generate booking ID
        String bookingId = bookingRepo.generateNextId();

        // Create booking
        Booking booking = new Booking(
                bookingId, userName, lockerId,
                LocalDateTime.now(), durationHours, totalCost
        );
        booking.validate();

        // Update locker status
        locker.occupy();
        lockerRepo.save(locker);

        // Save booking
        bookingRepo.save(booking);

        return booking;
    }

    public void completeBooking(String bookingId, String accessCode)
            throws InvalidInputException, IOException {

        // Validate inputs
        validator.validateNotEmpty(bookingId, "Booking ID");
        validator.validateNotEmpty(accessCode, "Access code");

        // Find booking
        Booking booking = bookingRepo.findById(bookingId);
        if (booking == null) {
            throw new InvalidInputException("Booking not found: " + bookingId);
        }

        // Verify access code
        if (!booking.getAccessCode().equals(accessCode)) {
            throw new InvalidInputException("Incorrect access code");
        }

        // Check if already completed
        if (booking.getActualEndTime() != null) {
            throw new InvalidInputException("Booking already completed");
        }

        // Complete booking
        booking.complete();

        // Release locker
        Locker locker = lockerRepo.findById(booking.getLockerId());
        if (locker != null) {
            locker.release();
            lockerRepo.save(locker);
        }

        // Save booking
        bookingRepo.save(booking);
    }

    public List<Booking> getAllBookings() {
        return bookingRepo.findAll();
    }

    public List<Booking> getBookingsByUser(String userName) {
        return bookingRepo.findByUserName(userName);
    }

    public List<Booking> getActiveBookings() {
        return bookingRepo.findActive();
    }

    public Booking getBookingById(String id) {
        return bookingRepo.findById(id);
    }
}