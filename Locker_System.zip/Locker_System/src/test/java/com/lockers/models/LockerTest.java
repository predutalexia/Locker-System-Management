package com.lockers.models;

import com.lockers.exceptions.InvalidInputException;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LockerTest {

    // Test constructor 1
    @Test
    public void testFullConstructor() {
        Locker locker = new Locker("L1", "A01", LockerSize.SMALL, 5.0);

        assertEquals("L1-A01", locker.getId());
        assertEquals("L1", locker.getLocationId());
        assertEquals("A01", locker.getLockerNumber());
        assertEquals(LockerSize.SMALL, locker.getSize());
        assertEquals(LockerStatus.AVAILABLE, locker.getStatus());
    }

    // Test constructor 2
    @Test
    public void testEmptyConstructor() {
        Locker locker = new Locker();
        assertEquals(LockerStatus.AVAILABLE, locker.getStatus());
    }

    // Test 1
    @Test
    public void testCalculateCost() {
        Locker locker = new Locker("L1", "A01", LockerSize.MEDIUM, 7.5);

        assertEquals(15.0, locker.calculateCost(2));
        assertEquals(37.5, locker.calculateCost(5));
    }

    // Test 2
    @Test
    public void testOccupyLocker() {
        Locker locker = new Locker("L1", "A01", LockerSize.SMALL, 5.0);

        assertTrue(locker.isAvailable());

        locker.occupy();

        assertFalse(locker.isAvailable());
        assertEquals(LockerStatus.OCCUPIED, locker.getStatus());
    }

    // Test 3
    @Test
    public void testReleaseLocker() {
        Locker locker = new Locker("L1", "A01", LockerSize.SMALL, 5.0);
        locker.occupy();

        locker.release();

        assertTrue(locker.isAvailable());
        assertEquals(LockerStatus.AVAILABLE, locker.getStatus());
    }
}