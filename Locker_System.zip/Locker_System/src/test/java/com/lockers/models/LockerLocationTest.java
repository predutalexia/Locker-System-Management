package com.lockers.models;

import com.lockers.exceptions.InvalidInputException;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LockerLocationTest {

    // Test constructor 1
    @Test
    public void testFullConstructor() {
        LockerLocation loc = new LockerLocation(
                "L1", "Train Station", "Main Street 1", 45.75, 21.23
        );

        assertEquals("L1", loc.getId());
        assertEquals("Train Station", loc.getName());
        assertEquals("Main Street 1", loc.getAddress());
        assertEquals(45.75, loc.getLatitude());
        assertEquals(21.23, loc.getLongitude());
        assertTrue(loc.isActive());
    }

    // Test constructor 2
    @Test
    public void testEmptyConstructor() {
        LockerLocation loc = new LockerLocation();

        assertTrue(loc.isActive());
        assertNotNull(loc.getLockers());
        assertEquals(0, loc.getLockers().size());
    }

    // Test 1
    @Test
    public void testAddLocker() throws InvalidInputException {
        LockerLocation loc = new LockerLocation(
                "L1", "Station", "Main St", 45.0, 21.0
        );
        Locker locker = new Locker("L1", "A01", LockerSize.SMALL, 5.0);

        loc.addLocker(locker);

        assertEquals(1, loc.getLockers().size());
        assertEquals(1, loc.getAvailableCount());
    }

    // Test 2
    @Test
    public void testDuplicateLockerNumberThrowsException() throws InvalidInputException {
        LockerLocation loc = new LockerLocation(
                "L1", "Station", "Main St", 45.0, 21.0
        );

        Locker locker1 = new Locker("L1", "A01", LockerSize.SMALL, 5.0);
        Locker locker2 = new Locker("L1", "A01", LockerSize.MEDIUM, 7.0);

        loc.addLocker(locker1);

        assertThrows(InvalidInputException.class, () -> loc.addLocker(locker2));
    }

    // Test 3
    @Test
    public void testGetAvailableCount() throws InvalidInputException {
        LockerLocation loc = new LockerLocation(
                "L1", "Station", "Main St", 45.0, 21.0
        );

        Locker l1 = new Locker("L1", "A01", LockerSize.SMALL, 5.0);
        Locker l2 = new Locker("L1", "A02", LockerSize.SMALL, 5.0);

        loc.addLocker(l1);
        loc.addLocker(l2);

        assertEquals(2, loc.getAvailableCount());

        l1.occupy();

        assertEquals(1, loc.getAvailableCount());
    }
}