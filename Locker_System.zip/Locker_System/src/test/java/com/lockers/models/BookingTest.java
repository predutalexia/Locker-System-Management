package com.lockers.models;

import com.lockers.exceptions.InvalidInputException;
import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

public class BookingTest {

    // Test constructor 1
    @Test
    public void testFullConstructor() {
        LocalDateTime now = LocalDateTime.now();
        Booking booking = new Booking("B1", "John", "L1-A01", now, 2, 15.0);

        assertEquals("B1", booking.getId());
        assertEquals("John", booking.getUserName());
        assertEquals("L1-A01", booking.getLockerId());
        assertEquals(15.0, booking.getTotalCost());
    }

    // Test constructor 2
    @Test
    public void testEmptyConstructor() {
        Booking booking = new Booking();
        assertNotNull(booking.getAccessCode());
    }

    // Test 1
    @Test
    public void testAccessCodeIsGenerated() {
        Booking booking = new Booking();
        String code = booking.getAccessCode();

        assertNotNull(code);
        assertEquals(6, code.length());
    }

    // Test 2
    @Test
    public void testCompleteBooking() {
        LocalDateTime now = LocalDateTime.now();
        Booking booking = new Booking("B1", "John", "L1-A01", now, 2, 15.0);

        assertNull(booking.getActualEndTime());

        booking.complete();

        assertNotNull(booking.getActualEndTime());
    }

    // Test 3
    @Test
    public void testValidationFailsWithEmptyUserName() {
        Booking booking = new Booking();
        booking.setUserName("");
        booking.setLockerId("L1");
        booking.setStartTime(LocalDateTime.now());
        booking.setExpectedEndTime(LocalDateTime.now().plusHours(2));
        booking.setTotalCost(10.0);

        assertThrows(InvalidInputException.class, () -> booking.validate());
    }
}