USE db;

ALTER TABLE locker_locations
ADD CONSTRAINT chk_latitude CHECK (latitude BETWEEN -90 AND 90);

ALTER TABLE locker_locations
ADD CONSTRAINT chk_longitude CHECK (longitude BETWEEN -180 AND 180);

CREATE TABLE lockers (
    id VARCHAR(50) PRIMARY KEY,
    location_id VARCHAR(50) NOT NULL,
    locker_number VARCHAR(20) NOT NULL,
    size VARCHAR(20) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'AVAILABLE',
    hourly_rate DOUBLE NOT NULL,
    
    CONSTRAINT fk_location 
        FOREIGN KEY (location_id) 
        REFERENCES locker_locations(id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
    
    CONSTRAINT chk_hourly_rate CHECK (hourly_rate > 0),
    CONSTRAINT uq_locker UNIQUE (location_id, locker_number)
);

CREATE TABLE bookings (
    id VARCHAR(50) PRIMARY KEY,
    user_name VARCHAR(100) NOT NULL,
    locker_id VARCHAR(50) NOT NULL,
    start_time TIMESTAMP NOT NULL,
    expected_end_time TIMESTAMP NOT NULL,
    actual_end_time TIMESTAMP NULL,
    access_code VARCHAR(10) NOT NULL,
    total_cost DOUBLE NOT NULL,
    
    CONSTRAINT fk_locker 
        FOREIGN KEY (locker_id) 
        REFERENCES lockers(id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
    
    CONSTRAINT chk_total_cost CHECK (total_cost >= 0)
);

CREATE TABLE users (
    username VARCHAR(50) PRIMARY KEY,
    password VARCHAR(100) NOT NULL,
    role VARCHAR(20) NOT NULL
);

INSERT INTO locker_locations VALUES 
    ('L1', 'Train Station', 'Main Street 1', 45.75, 21.23, TRUE),
    ('L2', 'City Center', 'Central Square 10', 45.76, 21.24, TRUE),
    ('L3', 'Shopping Mall', 'Mall Avenue 5', 45.74, 21.25, TRUE);
    
INSERT INTO lockers VALUES
    ('L1-A01', 'L1', 'A01', 'SMALL', 'AVAILABLE', 5.0),
    ('L1-A02', 'L1', 'A02', 'SMALL', 'AVAILABLE', 5.0),
    ('L1-A03', 'L1', 'A03', 'MEDIUM', 'AVAILABLE', 7.5),
    ('L1-A04', 'L1', 'A04', 'LARGE', 'AVAILABLE', 10.0),
    ('L2-B01', 'L2', 'B01', 'SMALL', 'AVAILABLE', 6.0),
    ('L2-B02', 'L2', 'B02', 'MEDIUM', 'AVAILABLE', 8.0);
    
INSERT INTO users VALUES
    ('admin', 'admin123', 'ADMIN'),
    ('user', 'user123', 'USER');
    
SELECT* FROM locker_locations;
SELECT* FROM lockers;
SELECT* FROM bookings;
SELECT* FROM users;

INSERT INTO bookings VALUES ('B001', 'Ion Popescu', 'L1-A01', NOW(), DATE_ADD(NOW(), INTERVAL 2 HOUR), NULL, '123456', 10.0);
UPDATE lockers SET status = 'OCCUPIED' WHERE id = 'L1-A01';
SELECT* FROM lockers WHERE id = 'L1-A01';
UPDATE bookings SET actual_end_time = NOW() WHERE id = 'B001';
UPDATE lockers SET status = 'AVAILABLE' WHERE id = 'L1-A01';
SHOW TABLES;
SELECT COUNT(*) FROM locker_locations;
SELECT COUNT(*) FROM lockers;
SELECT* FROM bookings WHERE id = 'B999';
SELECT* FROM lockers WHERE id = 'L1-A01';